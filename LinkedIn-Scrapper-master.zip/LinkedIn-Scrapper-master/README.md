# LinkedIn-Scrapper
LinkedIn profile data scrapper
